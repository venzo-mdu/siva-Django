from django.contrib import admin
from .models import log,Profile
# Register your models here.
admin.site.register(log)
admin.site.register(Profile)