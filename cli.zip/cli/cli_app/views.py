from django.shortcuts import render,redirect
from.models import log,Profile
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from.form import profile_form
from django.contrib.auth.decorators import login_required
# Create your views here.
def home(request):
    return render(request,'web.html')
def signup(request):
    password=request.POST.get('password')
    password2=request.POST.get('password2')
    if request.method=='POST' and password==password2:
        email=request.POST.get('email')
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=log.objects.create(email=email,password=password,username=username)
        user.save()
        return redirect('signin')
    return render(request,'index.html')
def signin(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        user=authenticate(request,username=email,password=password)
        if user is not None:
            login(request,user)
            return redirect('/home')
    messages.error(request,'wrong credential')
    return render(request,'signin.html')
@login_required(login_url='/signin')
def create_profile(request):
    form = profile_form
    if request.method == 'POST':
        form = profile_form(request.POST, files=request.FILES)
        if form.is_valid:
            obj = form.save(commit=False)
            obj.user=request.user
            obj=form.save()
            return redirect('viewprofile')
        else:
            messages.error('some error accuired')
    context={'form':form}
    return render(request,'profile.html',context)
@login_required(login_url='/signin')
def update_profile(request):
    obj = Profile.objects.get(user = request.user)
    form = profile_form(instance=obj)
    if request.method == 'POST':
        form = profile_form(request.POST,instance=obj,files=request.FILES)
        if form.is_valid:
            form.save()
            return redirect('viewprofile')
    context ={'form':form}
    return render(request,'update.html',context)
@login_required(login_url='/signin')
def viewprofile(request):
    # obj = Profile.objects.get(user = request.user)
    # form = profile_form(instance=obj)
    # if request.method == 'POST':
    #     form = profile_form(request.POST,instance=obj)
    #     if form.is_valid:
    #         form.save()
    #         return redirect('/')
    # context ={'form':form}
    return render(request,'viewprofile.html')
def signout(request):
    logout(request)
    return redirect('signin')
@login_required(login_url='/signin')
def delete_user(request):
    profile=log.objects.get(email=request.user)
    profile.delete()
    return redirect('signup')
